sudo pkill -f light.py
sudo python light.py 5

